<div class="container-fluid p-1 text-center" style="background-color: #808080; color: #FFFFFF; position: fixed; bottom: 0; width: 100%;">
    <p>Metache é uma marca registrada. Todos os direitos reservados. Os preços anunciados neste site promocional podem ser alterados sem prévio aviso. O Metache não é responsável por erros descritivos. Clique aqui e veja as políticas de nossa empresa.</p>
</div>
