<!-- views/linkView.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página com Link</title>
</head>
<body>
    <h1>Página com Link</h1>
    <a href="https://auth.mercadopago.com/authorization?client_id=6871026775986460&response_type=code&state=3&platform_id=mp&redirect_uri=http://localhost/dados">
        Clique aqui para autorizar e ver o token
    </a>
</body>
</html>
