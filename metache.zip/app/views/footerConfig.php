<div class="container-fluid p-2 text-center fixed-bottom" style="background-color: #808080; color: #FFFFFF; font-size: 0.875rem;">
    <p class="mb-1 d-inline d-md-block">
        Metache é uma marca registrada. Todos os direitos reservados. <span class="d-none d-md-inline">Os preços anunciados neste site promocional podem ser alterados sem prévio aviso. O Metache não é responsável por erros descritivos. <a href="/politicasEmpresa" style="color: #FF6B01; text-decoration: underline;">Clique aqui</a> para ver as políticas de nossa empresa.</span>
    </p>
    <p class="d-inline d-md-none" style="font-size: 0.75rem;"><a href="/politicasEmpresa" style="color: #FF6B01; text-decoration: underline;">Clique aqui</a> para ver as políticas de nossa empresa.</p>
</div>
