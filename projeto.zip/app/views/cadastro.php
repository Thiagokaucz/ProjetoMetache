<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
</head>
<body>
    <h2>Cadastro</h2>
    <form action="/cadastroUsuario" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required>
        <br>
        <label for="sobrenome">Sobrenome:</label>
        <input type="text" name="sobrenome" required>
        <br>
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        <br>
        <label for="senha">Senha:</label>
        <input type="password" name="senha" required>
        <br>
        <label for="cep">CEP:</label>
        <input type="text" name="cep" required>
        <br>
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>
