<?php require_once('header.php'); ?>
<h1>Pagina homel</h1>
<p>colocar aqui</p>
<?php require_once('footer.php'); ?>
