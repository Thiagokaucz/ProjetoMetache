<?php require_once('header.php'); ?>
<h1>Erro 404 - Página não encontrada</h1>
<p>A página não existe.</p>
<?php require_once('footer.php'); ?>
